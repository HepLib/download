cd ..
ls
cd usr/
ls
cd include/
ll -th
cd
ls
rm -rf Install/
x
